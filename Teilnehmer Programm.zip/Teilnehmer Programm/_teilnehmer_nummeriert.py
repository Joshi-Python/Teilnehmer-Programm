teilnehmer = [] # Liste für Teilnehmernamen

def teilnehmer_programm():
    print("Gib die Namen der Teilnehmer ein (mit 0 beenden):")
    while True:
        name = input("> ").strip()

        if name == "0":
           break

        if not name:
            print("Fehler: Bitte einen Namen eingeben (nicht leer).")
            continue
        if any(ch.isdigit() for ch in name):
            print("Fehler: Bitte einen Namen ohne Zahlen eingeben.")
            continue
        teilnehmer.append(name)

    if not teilnehmer:
        print("\nKeine Teilnehmer eingegeben.")
        return

    del teilnehmer[-1]
    print("\nDie Liste der Teilnehmer")
    print("============================")
    nummer = 1
    for name in teilnehmer:

        print(str(nummer) + ". " + name) # Nummer + Name anzeigen
        nummer += 1 # Nummer erhöhen
teilnehmer_programm()

